﻿namespace ASP.Models.FrontendForm
{
	public class FrontendFormOutput
	{
		public int Code { get; set; }
		public String Message { get; set; }
	}
}
