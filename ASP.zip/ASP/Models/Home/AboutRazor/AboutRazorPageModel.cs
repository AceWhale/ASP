﻿namespace ASP.Models.Home.AboutRazor
{
	public class AboutRazorPageModel
	{
		public String TabHeader { get; set; } = null!;
		public String PageTitle { get; set; } = null!;
		public String RazorIs { get; set; } = null!;
		public String RazorInstrc { get; set; } = null!;
	}
}
