﻿namespace ASP.Models.Home.Privacy
{
	public class PrivacyPageModel
	{
		public String TabHeader { get; set; } = null!;
		public String PageTitle { get; set; } = null!;
		public String PageText { get; set; } = null!;
	}
}
