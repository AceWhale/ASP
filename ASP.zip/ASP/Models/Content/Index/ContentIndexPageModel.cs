﻿using ASP.Data.Entities;

namespace ASP.Models.Content.Index
{
    public class ContentIndexPageModel
    {
        public List<Data.Entities.Category> Categories { get; set; } = [];
    }
}
